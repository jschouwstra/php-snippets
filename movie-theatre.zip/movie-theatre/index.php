<?php
$visitors = 5;
$gap = 0;
error_reporting(E_ALL & ~E_NOTICE);
$seats = array(
    array(
        'seatAvailable' => '0',
        'seatNumber' => '1'
    ),        
    array(
        'seatAvailable' => '0',
        'seatNumber' => '2'
    ),        
    array(
        'seatAvailable' => '1',
        'seatNumber' => '3'
    ),        
    array(
        'seatAvailable' => '1',
        'seatNumber' => '4'
    ),        
    array(
        'seatAvailable' => '1',
        'seatNumber' => '5'
    ),      
    array(
        'seatAvailable' => '0',
        'seatNumber' => '6'
    ),        
    array(
        'seatAvailable' => '0',
        'seatNumber' => '7'
    ),        
    array(
        'seatAvailable' => '1',
        'seatNumber' => '8'
    ),        
    array(
        'seatAvailable' => '1',
        'seatNumber' => '9'
    ),        
    array(
        'seatAvailable' => '1',
        'seatNumber' => '10'
    ),              
);
include "functions.php";

echo "Visitors: ".$visitors;
 


echo "<pre>";
$seats = (suggestSeats($seats,$visitors));

$savedSeats = saveSeats($seats);
print_r($savedSeats);
echo "</pre>";
?>