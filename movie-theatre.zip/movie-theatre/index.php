<?php
error_reporting(E_ALL & ~E_NOTICE);
        $seats = array(
            array(
                'seatAvailable' => '0',
                'seatNumber' => '1'
            ),        
            array(
                'seatAvailable' => '0',
                'seatNumber' => '2'
            ),        
            array(
                'seatAvailable' => '1',
                'seatNumber' => '3'
            ),        
            array(
                'seatAvailable' => '1',
                'seatNumber' => '4'
            ),        
            array(
                'seatAvailable' => '1',
                'seatNumber' => '5'
            ),      
            array(
                'seatAvailable' => '0',
                'seatNumber' => '6'
            ),        
            array(
                'seatAvailable' => '0',
                'seatNumber' => '7'
            ),        
            array(
                'seatAvailable' => '1',
                'seatNumber' => '8'
            ),        
            array(
                'seatAvailable' => '1',
                'seatNumber' => '9'
            ),        
            array(
                'seatAvailable' => '1',
                'seatNumber' => '10'
            ),              
        );
        include "functions.php";
?>
<html>
<head>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Bestel uw tickets</h1>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Aantal tickets:</label> 
                    <form name="TicketReservation" method="post">
                        <p><input name="visitors" type="text" value="<?php if(isset($_POST['visitors'])){echo $_POST['visitors'];}else{echo 0;}?>" class="form-control">
                        </p>
                        <p><input name="submitTicketOrder" type="submit" value="Reserveer Plaatsen" class="form-control"></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Beschikbaarheid stoelen</h2>
            </div>
        </div>        
        <div class="row">
            <div class="col-md-6">
                <p>Deze stoelen zijn nog beschikbaar.</p>
            </div>
        </div>
    </div>    
<?php
    showSeats($seats);

if(isset($_POST['submitTicketOrder'])){
    $visitors = $_POST['visitors'];    
    if($visitors){
        $gap = 0;
        $seats = (suggestSeats($seats,$visitors));
        if(!$seats){
            // echo "
            // <div class=\"container\">
            //     <div class=\"row\">
            //         <div class=\"col-md-6\">
            //         <p>
            //         <div class=\"alert alert-danger\">Sorry, niet genoeg zitplaatsen.</div>
            //         </p>
            //         </div
            //     </div>
            // </div> 
            // ";
            layoutError("Sorry, niet genoeg zitplaatsen.");

        }else{?>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>Uw reservering</h2>
                </div>
            </div>        
            <div class="row">
                <div class="col-md-6">
                    <p>Deze stoelen worden u aangeboden.</p>
                </div>
            </div>
        </div>   
        <?php

            showSeats($seats);

        
        ?>
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                    <p>
                    <div class="alert alert-success">Opgeslagen in de database.</div>
                    </p>
                    </div
                </div>
            </div> 

        <?php
            //The arrangements are being saved
            saveSeats($seats); 
    }

    }
    else{
        // echo "
        // <div class=\"container\">
        //     <div class=\"row\">
        //         <div class=\"col-md-6\">
        //         <p>
        //         <div class=\"alert alert-danger\">Gelieve een aantal tickets in te voeren.</div>
        //         </p>
        //         </div
        //     </div>
        // </div> 
        // ";
            layoutError("Gelieve een aantal tickets in te voeren..");

    }
  
}


?>
</body>
</html>